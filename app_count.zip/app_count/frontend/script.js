const API_BASE_URL = "https://tasbih-flask.onrender.com";  // Flask Backend ka Link

function fetchCount() {
    fetch(`${API_BASE_URL}/get_count`)
    .then(response => response.json())
    .then(data => {
        document.getElementById("count").innerText = data.count;
    });
}

function incrementCount() {
    fetch(`${API_BASE_URL}/increment`, { method: "POST" })
    .then(() => fetchCount());
}

function resetCount() {
    fetch(`${API_BASE_URL}/reset`, { method: "POST" })
    .then(() => fetchCount());
}

// Page Load pe Data Fetch Karein
fetchCount();