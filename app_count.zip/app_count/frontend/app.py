from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

# Database Initialization
def init_db():
    with sqlite3.connect("tasbih.db") as conn:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS counter (id INTEGER PRIMARY KEY, count INTEGER DEFAULT 0)''')
        cursor.execute('''INSERT OR IGNORE INTO counter (id, count) VALUES (1, 0)''')
        conn.commit()

@app.route("/get_count", methods=["GET"])
def get_count():
    with sqlite3.connect("tasbih.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT count FROM counter WHERE id=1")
        count = cursor.fetchone()[0]
    return jsonify({"count": count})

@app.route("/increment", methods=["POST"])
def increment():
    with sqlite3.connect("tasbih.db") as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE counter SET count = count + 1 WHERE id=1")
        conn.commit()
    return jsonify({"message": "Count incremented"})

@app.route("/reset", methods=["POST"])
def reset():
    with sqlite3.connect("tasbih.db") as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE counter SET count = 0 WHERE id=1")
        conn.commit()
    return jsonify({"message": "Count reset"})

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)